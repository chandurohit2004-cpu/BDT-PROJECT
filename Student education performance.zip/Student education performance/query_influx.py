import os
import pandas as pd
from influxdb_client import InfluxDBClient

TOKEN = "super-secret-spark-token"
ORG = "edu-analytics"
BUCKET = "academic_metrics"
URL = "http://localhost:8086"

client = InfluxDBClient(url=URL, token=TOKEN, org=ORG)

query = f"""
from(bucket: "{BUCKET}")
  |> range(start: -24h)
  |> filter(fn: (r) => r["_measurement"] == "dept_performance")
  |> filter(fn: (r) => r["_field"] == "marks")
  |> last()
  |> group()
"""

df = client.query_api().query_data_frame(org=ORG, query=query)
print(df)
client.close()
