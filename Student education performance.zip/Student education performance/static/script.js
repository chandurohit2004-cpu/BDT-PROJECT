document.addEventListener('DOMContentLoaded', () => {
    console.log('College Dashboard Script Initialized');
    // Global variables for charts
    let charts = {};

    // Analytics Rendering Functions (Definition at top)
    async function fetchAnalytics() {
        console.log('Analytics triggered at', new Date().toLocaleTimeString());
        if (typeof Chart === 'undefined') {
            alert('Chart.js library not detected. Please check your internet connection.');
            return;
        }
        try {
            const response = await fetch(`/api/analytics?t=${Date.now()}`);
            const data = await response.json();
            console.log('Analytics data received:', data);

            if (!data || data.error) throw new Error(data.error || 'No data');

            // Set a small nested timeout to ensure DOM is absolutely ready
            setTimeout(() => {
                if (data.grade_distribution) renderGradeChart(data.grade_distribution);
                if (data.department_stats) {
                    renderDeptChart(data.department_stats);
                    renderAttendanceChart(data.department_stats);
                }
                if (data.backlog_distribution) renderBacklogChart(data.backlog_distribution);

                // Force a resize event to jumpstart Chart.js layout
                window.dispatchEvent(new Event('resize'));
            }, 100);
        } catch (err) {
            console.error('Failed to fetch analytics:', err);
        }
    }

    function renderGradeChart(dist) {
        const el = document.getElementById('gradeChart');
        if (!el) return;
        const ctx = el.getContext('2d');
        if (charts.grade) charts.grade.destroy();

        charts.grade = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(dist),
                datasets: [{
                    data: Object.values(dist),
                    backgroundColor: ['#a01a31', '#d4203d', '#fecaca', '#fee2e2', '#1f2937']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 1000 }
            }
        });
    }

    function renderDeptChart(stats) {
        const el = document.getElementById('deptChart');
        if (!el) return;
        const ctx = el.getContext('2d');
        if (charts.dept) charts.dept.destroy();

        charts.dept = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(stats),
                datasets: [{
                    label: 'Avg Total Marks',
                    data: Object.values(stats).map(s => s.Total_Marks),
                    backgroundColor: '#a01a31'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 1000 }
            }
        });
    }

    function renderAttendanceChart(stats) {
        const el = document.getElementById('attendanceChart');
        if (!el) return;
        const ctx = el.getContext('2d');
        if (charts.att) charts.att.destroy();

        charts.att = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Object.keys(stats),
                datasets: [{
                    label: 'Avg Attendance %',
                    data: Object.values(stats).map(s => s['Attendance (%)']),
                    borderColor: '#d4203d',
                    tension: 0.3,
                    fill: true,
                    backgroundColor: 'rgba(212, 32, 61, 0.1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 1000 }
            }
        });
    }

    function renderBacklogChart(dist) {
        const el = document.getElementById('backlogChart');
        if (!el) return;
        const ctx = el.getContext('2d');
        if (charts.backlog) charts.backlog.destroy();

        charts.backlog = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: Object.keys(dist).map(k => `${k} Backlogs`),
                datasets: [{
                    data: Object.values(dist),
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#1f2937', '#a01a31', '#d4203d']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 1000 }
            }
        });
    }

    // Navigation Logic
    const navItems = document.querySelectorAll('.sidebar-nav li');
    const sections = document.querySelectorAll('.content-section');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const target = item.getAttribute('data-target');
            if (!target) return;

            // Update active nav
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // Show target section
            sections.forEach(sec => {
                sec.classList.remove('active');
                if (sec.id === `${target}-section`) {
                    sec.classList.add('active');
                    // Re-trigger analytics charts if analytics section is opened
                    if (target === 'analysis') {
                        setTimeout(() => fetchAnalytics(), 1100);
                    }
                    if (target === 'burnout') {
                        setTimeout(() => fetchBurnout(), 1100);
                    }
                }
            });
        });
    });

    // Initial Data Fetch
    fetchStats();
    fetchNotifications();
    renderCalendar();

    // Refresh button for analytics
    const refreshAnalyticsBtn = document.getElementById('refresh-analytics');
    if (refreshAnalyticsBtn) {
        refreshAnalyticsBtn.addEventListener('click', () => {
            fetchAnalytics();
        });
    }

    // Burnout Detector Logic
    async function fetchBurnout() {
        try {
            const response = await fetch('/api/burnout');
            const data = await response.json();

            if (data.error) throw new Error(data.error);

            renderBurnoutChart(data.risk_distribution);
            populateBurnoutWatchlist(data.watchlist);

            const recEl = document.getElementById('burnout-recommendation');
            if (data.avg_burnout > 60) {
                recEl.textContent = "Critical: Average student stress levels are high. Recommended immediate well-being check-ins for the EEE and CSE departments.";
            } else if (data.avg_burnout > 40) {
                recEl.textContent = "Moderate: Engagement decay detected in Semester 4. Recommend faculty review of assignment deadlines.";
            } else {
                recEl.textContent = "Healthy: Student engagement is stable across most sectors. Keep up the positive reinforcement!";
            }
        } catch (err) {
            console.error('Failed to fetch burnout data', err);
        }
    }

    function renderBurnoutChart(riskDist) {
        const options = {
            series: [riskDist.Low, riskDist.Moderate, riskDist.High],
            chart: {
                height: 350,
                type: 'donut',
                fontFamily: 'Outfit, sans-serif'
            },
            labels: ['Low Risk', 'Moderate Risk', 'High Burnout'],
            colors: ['#10b981', '#f59e0b', '#ef4444'],
            plotOptions: {
                pie: {
                    donut: {
                        size: '75%',
                        labels: {
                            show: true,
                            total: {
                                show: true,
                                label: 'Avg Risk',
                                formatter: () => 'Moderate'
                            }
                        }
                    }
                }
            },
            legend: { position: 'bottom' },
            theme: { mode: document.body.classList.contains('dark-theme') ? 'dark' : 'light' }
        };

        const chartContainer = document.getElementById('burnout-chart');
        if (chartContainer) {
            chartContainer.innerHTML = '';
            const chart = new ApexCharts(chartContainer, options);
            chart.render();
        }
    }

    function populateBurnoutWatchlist(watchlist) {
        const tbody = document.getElementById('burnout-watchlist');
        if (!tbody) return;

        tbody.innerHTML = watchlist.map(s => `
            <tr style="border-bottom: 1px solid var(--gray-100);">
                <td style="padding: 12px; font-weight: 600;">${s.Student_Name}</td>
                <td style="padding: 12px; color: var(--gray-600);">${s.Department}</td>
                <td style="padding: 12px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="flex: 1; height: 6px; background: #fee2e2; border-radius: 3px;">
                            <div style="width: ${s.Burnout_Score}%; height: 100%; background: #ef4444; border-radius: 3px;"></div>
                        </div>
                        <span style="font-size: 11px; font-weight: 700; color: #ef4444;">${Math.round(s.Burnout_Score)}%</span>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Student Search & Form Population (Restored)
    const studentSearch = document.getElementById('studentSearch');
    const studentList = document.getElementById('studentList');

    if (studentSearch) {
        studentSearch.addEventListener('input', async (e) => {
            const query = e.target.value;
            if (query.length < 2) return;

            try {
                const response = await fetch(`/api/students?q=${encodeURIComponent(query)}`);
                const students = await response.json();

                if (studentList) {
                    studentList.innerHTML = '';
                    students.forEach(s => {
                        const option = document.createElement('option');
                        option.value = s.Student_Name;
                        studentList.appendChild(option);
                    });
                }

                // Check if exact match was selected
                const selectedMatch = students.find(s => s.Student_Name.trim().toLowerCase() === query.trim().toLowerCase());
                if (selectedMatch) {
                    populateForm(selectedMatch);
                }
            } catch (err) {
                console.error('Lookup failed', err);
            }
        });
    }

    function populateForm(student) {
        const internalInput = document.querySelector('input[name="internal"]');
        const externalInput = document.querySelector('input[name="external"]');
        const attendanceInput = document.querySelector('input[name="attendance"]');
        const backlogsInput = document.querySelector('input[name="backlogs"]');

        if (internalInput) internalInput.value = student.Internal_Marks;
        if (externalInput) externalInput.value = student.External_Marks;
        if (attendanceInput) attendanceInput.value = student['Attendance (%)'];
        if (backlogsInput) backlogsInput.value = student.Backlogs;

        // Visual feedback
        if (studentSearch) {
            studentSearch.classList.add('success-border');
            setTimeout(() => studentSearch.classList.remove('success-border'), 1000);
        }
    }

    // Student Eligibility Search
    const eligibilitySearch = document.getElementById('eligibilitySearch');
    const eligibilityResult = document.getElementById('eligibility-result');

    eligibilitySearch.addEventListener('input', async (e) => {
        const query = e.target.value;
        if (query.length < 2) return;

        try {
            const response = await fetch(`/api/students?q=${encodeURIComponent(query)}`);
            const students = await response.json();

            // Check if exact match was selected (case-insensitive & trimmed)
            const selectedMatch = students.find(s => s.Student_Name.trim().toLowerCase() === query.trim().toLowerCase());
            if (selectedMatch) {
                checkEligibility(selectedMatch);
            }
        } catch (err) {
            console.error('Eligibility lookup failed', err);
        }
    });

    function checkEligibility(student) {
        eligibilityResult.classList.remove('hidden');
        document.getElementById('elig-student-name').textContent = student.Student_Name;
        document.getElementById('elig-student-id').textContent = student.Student_ID;

        // 1. Backlog Rule (Max 2)
        const backlogs = student.Backlogs;
        const backlogItem = document.getElementById('check-backlogs');
        if (backlogs <= 2) {
            updateCheckItem(backlogItem, true, `${backlogs} Backlogs (Pass)`);
        } else {
            updateCheckItem(backlogItem, false, `${backlogs} Backlogs (Criteria: Max 2)`);
        }

        // 2. Attendance Rule (Min 75%)
        const attendance = student['Attendance (%)'];
        const attendanceItem = document.getElementById('check-attendance');
        if (attendance >= 75) {
            updateCheckItem(attendanceItem, true, `${attendance}% Attendance (Pass)`);
        } else {
            updateCheckItem(attendanceItem, false, `${attendance}% Attendance (Criteria: Min 75%)`);
        }

        // 3. Academic Threshold (Min 60 Total)
        const totalMarks = (student.Internal_Marks || 0) + (student.External_Marks || 0);
        const marksItem = document.getElementById('check-marks');
        if (totalMarks >= 60) {
            updateCheckItem(marksItem, true, `${totalMarks} Total Marks (Pass)`);
        } else {
            updateCheckItem(marksItem, false, `${totalMarks} Total Marks (Criteria: Min 60)`);
        }

        // Overall Status
        const statusBadge = document.getElementById('eligibility-status-badge');
        const isEligible = (backlogs <= 2 && attendance >= 75 && totalMarks >= 60);

        if (isEligible) {
            statusBadge.textContent = 'ELIGIBLE';
            statusBadge.style.background = '#dcfce7';
            statusBadge.style.color = '#166534';
        } else {
            statusBadge.textContent = 'INELIGIBLE';
            statusBadge.style.background = '#fee2e2';
            statusBadge.style.color = '#991b1b';
        }
    }

    function updateCheckItem(element, isPass, text) {
        const icon = element.querySelector('.c-icon');
        const desc = element.querySelector('span[id^="desc-"]');
        desc.textContent = text;

        if (isPass) {
            icon.innerHTML = '<i class="fas fa-check-circle" style="color: #16a34a;"></i>';
            element.style.borderColor = '#bbf7d0';
        } else {
            icon.innerHTML = '<i class="fas fa-times-circle" style="color: #dc2626;"></i>';
            element.style.borderColor = '#fecaca';
        }
    }

    // Settings Toggles Interactivity
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const emailNotifToggle = document.getElementById('email-notif-toggle');

    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            const circle = darkModeToggle.querySelector('div');
            const isActive = darkModeToggle.style.background === 'var(--primary)';
            if (isActive) {
                darkModeToggle.style.background = 'var(--gray-300)';
                circle.style.left = '3px';
                circle.style.right = 'auto';
                document.body.classList.remove('dark-theme');
            } else {
                darkModeToggle.style.background = 'var(--primary)';
                circle.style.left = 'auto';
                circle.style.right = '3px';
                document.body.classList.add('dark-theme');
            }
            // Trigger Heatmap Theme Update
            if (charts.heatmap) {
                charts.heatmap.updateOptions({
                    theme: { mode: document.body.classList.contains('dark-theme') ? 'dark' : 'light' }
                });
            }
        });
    }

    if (emailNotifToggle) {
        emailNotifToggle.addEventListener('click', () => {
            const circle = emailNotifToggle.querySelector('div');
            const isActive = emailNotifToggle.style.background === 'var(--primary)';
            if (isActive) {
                emailNotifToggle.style.background = 'var(--gray-300)';
                circle.style.left = '3px';
                circle.style.right = 'auto';
            } else {
                emailNotifToggle.style.background = 'var(--primary)';
                circle.style.left = 'auto';
                circle.style.right = '3px';
            }
        });
    }


    // Update fetchStats to also trigger analytics
    async function fetchStats() {
        try {
            const response = await fetch('/api/stats');
            const data = await response.json();

            if (data.error) throw new Error(data.error);

            // Update Header Stats
            document.getElementById('total-students').textContent = data.total_students;
            document.getElementById('avg-attendance').textContent = `${data.avg_attendance} % `;
            document.getElementById('pass-rate').textContent = `${data.pass_rate} % `;
            document.getElementById('at-risk-count').textContent = data.at_risk_count;

            // Updated: Fetch Heatmap instead of populating old list
            fetchHeatmapData();

            // Stats loaded successfully

        } catch (error) {
            console.error('Error fetching stats:', error);
        }
    }

    // Add New Entry Modal Logic
    const entryModal = document.getElementById('entryModal');
    const addEntryBtn = document.querySelector('.btn-primary'); // Add New Entry button
    const closeModal = document.getElementById('closeModal');
    const newEntryForm = document.getElementById('new-entry-form');

    if (addEntryBtn) {
        addEntryBtn.addEventListener('click', () => {
            entryModal.classList.add('active');
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            entryModal.classList.remove('active');
        });
    }

    // Close on outside click
    window.addEventListener('click', (e) => {
        if (e.target === entryModal) {
            entryModal.classList.remove('active');
        }
    });

    if (newEntryForm) {
        newEntryForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(newEntryForm);
            const jsonData = Object.fromEntries(formData.entries());

            // Numeric conversions
            jsonData['Internal_Marks'] = parseInt(jsonData['Internal_Marks']);
            jsonData['External_Marks'] = parseInt(jsonData['External_Marks']);
            jsonData['Attendance (%)'] = parseInt(jsonData['Attendance (%)']);
            jsonData['Backlogs'] = parseInt(jsonData['Backlogs']);

            try {
                const response = await fetch('/api/add-student', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(jsonData)
                });

                const result = await response.json();

                if (result.status === 'Success') {
                    alert('Student entry added successfully!');
                    entryModal.classList.remove('active');
                    newEntryForm.reset();
                    // Refresh stats if needed
                    fetchStats();
                } else {
                    alert('Error adding entry: ' + result.error);
                }
            } catch (err) {
                console.error('Submission failed', err);
            }
        });
    }

    // Correlation Heatmap Functions
    async function fetchHeatmapData() {
        try {
            const response = await fetch('/api/heatmap-data');
            const data = await response.json();
            if (data.series) {
                renderHeatmap(data.series);
            }
        } catch (error) {
            console.error('Error fetching heatmap data:', error);
        }
    }

    function renderHeatmap(series) {
        const heatmapEl = document.querySelector("#heatmap-chart");
        if (!heatmapEl) return;

        heatmapEl.innerHTML = ''; // Clear existing

        const options = {
            series: series,
            chart: {
                height: 350,
                type: 'heatmap',
                toolbar: { show: false },
                background: 'transparent',
                fontFamily: 'Inter, sans-serif'
            },
            dataLabels: { enabled: false },
            colors: ["#a01a31"],
            xaxis: {
                type: 'category',
                labels: { style: { colors: '#64748b' } }
            },
            yaxis: {
                labels: { style: { colors: '#64748b' } }
            },
            plotOptions: {
                heatmap: {
                    shadeIntensity: 0.5,
                    radius: 4,
                    useFillColorAsStroke: true,
                    colorScale: {
                        ranges: [
                            { from: 0, to: 5, name: 'low', color: '#fee1e1' },
                            { from: 6, to: 15, name: 'medium', color: '#fca5a5' },
                            { from: 16, to: 30, name: 'high', color: '#dc2626' },
                            { from: 31, to: 100, name: 'critical', color: '#991b1b' }
                        ]
                    }
                }
            },
            theme: { mode: document.body.classList.contains('dark-theme') ? 'dark' : 'light' },
            tooltip: { theme: 'dark' }
        };

        if (charts.heatmap) charts.heatmap.destroy();
        charts.heatmap = new ApexCharts(heatmapEl, options);
        charts.heatmap.render();
    }

    // Calendar Logic
    function renderCalendar() {
        const daysContainer = document.getElementById('calendar-days');
        if (!daysContainer) return;

        daysContainer.innerHTML = '';
        const now = new Date();
        const year = 2026;
        const month = 1; // February (0-indexed)

        // Mock data for February 2026
        const events = {
            5: { type: 'exam', title: 'Internal Exam - Unit 1' },
            12: { type: 'holiday', title: 'Lincoln Birthday' },
            15: { type: 'exam', title: 'Internal Exam - Unit 2' },
            23: { type: 'holiday', title: 'Washington Birthday' },
            25: { type: 'exam', title: 'End Semester Practical' }
        };

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Add empty cells for days before the 1st
        for (let i = 0; i < firstDay; i++) {
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'calendar-day other-month';
            daysContainer.appendChild(emptyDiv);
        }

        // Render month days
        for (let d = 1; d <= daysInMonth; d++) {
            const dayDiv = document.createElement('div');
            dayDiv.className = 'calendar-day';
            dayDiv.textContent = d;

            if (events[d]) {
                dayDiv.classList.add(events[d].type);
                dayDiv.title = events[d].title;
            }

            // Highlight today if it matches
            if (now.getDate() === d && now.getMonth() === month && now.getFullYear() === year) {
                dayDiv.classList.add('today');
            }

            daysContainer.appendChild(dayDiv);
        }
    }

    // Notifications & Messages Logic
    const notifTrigger = document.getElementById('notif-trigger');
    const notifDropdown = document.getElementById('notif-dropdown');
    const notifBadge = document.getElementById('notif-badge');
    const notifItems = document.getElementById('notif-items');

    const msgTrigger = document.getElementById('msg-trigger');
    const msgDropdown = document.getElementById('msg-dropdown');
    const msgBadge = document.getElementById('msg-badge');
    const msgItems = document.getElementById('msg-items');

    // Toggle Dropdowns
    if (notifTrigger) {
        notifTrigger.addEventListener('click', (e) => {
            e.stopPropagation();
            notifDropdown.classList.toggle('active');
            msgDropdown.classList.remove('active');
            if (notifDropdown.classList.contains('active')) {
                // Clear badge when viewed (simplified logic)
                notifBadge.classList.remove('active');
            }
        });
    }

    if (msgTrigger) {
        msgTrigger.addEventListener('click', (e) => {
            e.stopPropagation();
            msgDropdown.classList.toggle('active');
            notifDropdown.classList.remove('active');
            if (msgDropdown.classList.contains('active')) {
                msgBadge.classList.remove('active');
            }
        });
    }

    // Close on outside click
    window.addEventListener('click', () => {
        if (notifDropdown) notifDropdown.classList.remove('active');
        if (msgDropdown) msgDropdown.classList.remove('active');
    });

    async function fetchNotifications() {
        try {
            const response = await fetch('/api/notifications');
            const data = await response.json();

            if (data.length > 0) {
                notifBadge.textContent = data.length;
                notifBadge.classList.add('active');

                notifItems.innerHTML = '';
                data.forEach(n => {
                    const item = document.createElement('div');
                    item.className = 'notif-item';
                    item.innerHTML = `
        < div class= "n-icon ${n.type}" >
        <i class="fas ${n.icon}"></i>
                        </div >
            <div class="n-details">
                <p><strong>${n.title}</strong></p>
                <p>${n.message}</p>
                <span class="time">${n.time}</span>
            </div>
                    `;
                    notifItems.appendChild(item);
                });
            }
        } catch (err) {
            console.error('Failed to fetch notifications', err);
        }
    }

    async function fetchMessages() {
        try {
            const response = await fetch('/api/messages');
            const data = await response.json();

            if (data.length > 0) {
                msgBadge.textContent = data.length;
                msgBadge.classList.add('active');

                msgItems.innerHTML = '';
                data.forEach(m => {
                    const item = document.createElement('div');
                    item.className = 'msg-item';
                    item.innerHTML = `
            < img src = "${m.avatar}" alt = "Avatar" style = "width: 36px; height: 36px; border-radius: 50%;" >
            <div class="m-details">
                <p><strong>${m.sender}</strong></p>
                <p style="font-size: 11px; color: var(--primary);">${m.subject}</p>
                <p>${m.preview}</p>
                <span class="time">${m.time}</span>
            </div>
                    `;
                    msgItems.appendChild(item);
                });
            }
        } catch (err) {
            console.error('Failed to fetch messages', err);
        }
    }

    // Data Management Hub Logic
    const dropZone = document.getElementById('drop-zone');
    const csvInput = document.getElementById('csv-upload');
    const uploadStatus = document.getElementById('upload-status');
    const exportFullBtn = document.getElementById('export-full');
    const exportRiskBtn = document.getElementById('export-risk');

    // Drag and Drop Handlers
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file && file.name.endsWith('.csv')) {
                handleFileUpload(file);
            } else {
                showUploadStatus('Please upload a valid CSV file.', 'error');
            }
        });

        csvInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) handleFileUpload(file);
        });
    }

    async function handleFileUpload(file) {
        showUploadStatus('Uploading and processing...', 'info');

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/upload-csv', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (result.status === 'Success') {
                showUploadStatus(`Success! Imported ${result.count} student records.`, 'success');
                fetchStats(); // Refresh dashboard stats
            } else {
                showUploadStatus(`Error: ${result.error}`, 'error');
            }
        } catch (err) {
            console.error('Upload failed', err);
            showUploadStatus('Network error occurred during upload.', 'error');
        }
    }

    function showUploadStatus(msg, type) {
        uploadStatus.textContent = msg;
        uploadStatus.className = `status - msg ${type}`;
        uploadStatus.classList.remove('hidden');
    }

    // Export Logic
    if (exportFullBtn) {
        exportFullBtn.addEventListener('click', () => {
            window.location.href = '/api/export-csv?type=full';
        });
    }

    if (exportRiskBtn) {
        exportRiskBtn.addEventListener('click', () => {
            window.location.href = '/api/export-csv?type=risk';
        });
    }

    // ── Export Preview Modal ──────────────────────────────────────────────
    const exportPreviewModal = document.getElementById('exportPreviewModal');
    const closeExportPreview = document.getElementById('closeExportPreview');
    const viewFullBtn = document.getElementById('view-full');
    const viewRiskBtn = document.getElementById('view-risk');
    const previewDownloadBtn = document.getElementById('preview-download-btn');
    const previewSearch = document.getElementById('preview-search');
    const previewThead = document.getElementById('preview-thead');
    const previewTbody = document.getElementById('preview-tbody');
    const previewLoading = document.getElementById('preview-loading');
    const previewEmpty = document.getElementById('preview-empty');
    const previewRecordCount = document.getElementById('preview-record-count');
    const previewPageInfo = document.getElementById('preview-page-info');
    const previewPrev = document.getElementById('preview-prev');
    const previewNext = document.getElementById('preview-next');

    let previewAllRows = [];
    let previewFilteredRows = [];
    let previewCurrentPage = 1;
    let previewCurrentType = 'full';
    const ROWS_PER_PAGE = 15;

    let currentColumns = [
        { key: 'Student_ID', label: 'ID' },
        { key: 'Student_Name', label: 'Name' },
        { key: 'Department', label: 'Dept' },
        { key: 'Attendance (%)', label: 'Attend %' },
        { key: 'Internal_Marks', label: 'Internal' },
        { key: 'External_Marks', label: 'External' },
        { key: 'Total_Marks', label: 'Total' },
        { key: 'Backlogs', label: 'Backlogs' },
        { key: 'Grade', label: 'Grade' }
    ];

    const SPARK_COLUMNS = [
        { key: 'Student_ID', label: 'ID' },
        { key: 'Student_Name', label: 'Name' },
        { key: 'Department', label: 'Dept' },
        { key: 'Backlogs', label: 'Backlogs' },
        { key: 'Intervention_Priority', label: 'Priority' },
        { key: 'Recommendation', label: 'Spark Recommendation' }
    ];

    const GRADE_COLORS = {
        'A+': { bg: '#dcfce7', color: '#166534' },
        'A': { bg: '#d1fae5', color: '#065f46' },
        'B+': { bg: '#dbeafe', color: '#1e40af' },
        'B': { bg: '#ede9fe', color: '#5b21b6' },
        'C': { bg: '#fef9c3', color: '#854d0e' },
        'D': { bg: '#fee2e2', color: '#991b1b' },
        'F': { bg: '#fecaca', color: '#7f1d1d' }
    };

    function openPreviewModal(type) {
        previewCurrentType = type;
        previewCurrentPage = 1;
        previewSearch.value = '';

        const isRisk = type === 'risk';
        document.getElementById('preview-modal-title').textContent = isRisk ? 'At-Risk Students Preview' : 'Full Database Preview';
        document.getElementById('preview-modal-subtitle').textContent = isRisk ? 'Showing students with attendance < 75%' : 'Showing all student records';
        previewDownloadBtn.style.color = '#a01a31';
        previewDownloadBtn.onclick = () => { window.location.href = `/ api /export -csv ? type = ${type}`; };

        // Show modal
        exportPreviewModal.classList.remove('hidden');
        requestAnimationFrame(() => {
            exportPreviewModal.style.opacity = '1';
            exportPreviewModal.style.pointerEvents = 'auto';
            exportPreviewModal.querySelector('.export-preview-modal-content').style.transform = 'scale(1)';
        });

        // Reset table state
        previewTbody.innerHTML = '';
        previewThead.innerHTML = '';
        previewLoading.style.display = 'block';
        previewEmpty.classList.add('hidden');
        previewRecordCount.textContent = '';
        previewPageInfo.textContent = '';

        fetchPreviewData(type);
    }

    function closePreviewModal() {
        exportPreviewModal.style.opacity = '0';
        exportPreviewModal.style.pointerEvents = 'none';
        exportPreviewModal.querySelector('.export-preview-modal-content').style.transform = 'scale(0.93)';
        setTimeout(() => exportPreviewModal.classList.add('hidden'), 300);
    }

    async function fetchPreviewData(type) {
        try {
            const response = await fetch(`/api/preview-students?type=${type}`);
            const data = await response.json();
            previewLoading.style.display = 'none';

            previewAllRows = data.students || [];
            previewFilteredRows = [...previewAllRows];

            // Dynamically switch column set based on data source
            if (data.source === 'Apache Spark') {
                currentColumns = SPARK_COLUMNS;
            } else {
                currentColumns = [
                    { key: 'Student_ID', label: 'ID' },
                    { key: 'Student_Name', label: 'Name' },
                    { key: 'Department', label: 'Dept' },
                    { key: 'Attendance (%)', label: 'Attend %' },
                    { key: 'Internal_Marks', label: 'Internal' },
                    { key: 'External_Marks', label: 'External' },
                    { key: 'Total_Marks', label: 'Total' },
                    { key: 'Backlogs', label: 'Backlogs' },
                    { key: 'Grade', label: 'Grade' }
                ];
            }

            renderPreviewTable();
        } catch (err) {
            console.error('Preview fetch error:', err);
            previewLoading.textContent = 'Failed to load data.';
        }
    }

    function renderPreviewTable() {
        const total = previewFilteredRows.length;
        const totalPages = Math.max(1, Math.ceil(total / ROWS_PER_PAGE));
        previewCurrentPage = Math.min(previewCurrentPage, totalPages);

        const start = (previewCurrentPage - 1) * ROWS_PER_PAGE;
        const pageRows = previewFilteredRows.slice(start, start + ROWS_PER_PAGE);

        // Build header
        previewThead.innerHTML = `<tr>${currentColumns.map(c => `<th style="padding: 12px 14px; text-align: left; font-size: 0.8em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #64748b; white-space: nowrap;">${c.label}</th>`).join('')}<th style="padding: 12px 14px; text-align: left; font-size: 0.8em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #64748b; white-space: nowrap;">Actions</th></tr>`;

        // Build rows
        if (pageRows.length === 0) {
            previewEmpty.classList.remove('hidden');
            previewTbody.innerHTML = '';
        } else {
            previewEmpty.classList.add('hidden');
            previewTbody.innerHTML = pageRows.map((row, idx) => {
                const isEven = idx % 2 === 0;
                return `<tr style="background: ${isEven ? '#ffffff' : '#f8fafc'}; transition: background 0.15s;" onmouseover="this.style.background='#f0fdf4'" onmouseout="this.style.background='${isEven ? '#ffffff' : '#f8fafc'}'">${currentColumns.map(c => {
                    let val = row[c.key] ?? '—';
                    let cell = '';
                    if (c.key === 'Grade') {
                        const gc = GRADE_COLORS[val] || { bg: '#f1f5f9', color: '#374151' };
                        cell = `<span style="background:${gc.bg}; color:${gc.color}; padding: 3px 10px; border-radius: 20px; font-weight: 700; font-size: 0.85em;">${val}</span>`;
                    } else if (c.key === 'Intervention_Priority') {
                        const isCritical = val === 'CRITICAL';
                        const isModerate = val === 'MODERATE';
                        const bg = isCritical ? '#fee2e2' : isModerate ? '#fef9c3' : '#dcfce7';
                        const co = isCritical ? '#991b1b' : isModerate ? '#854d0e' : '#166534';
                        cell = `<span style="background:${bg}; color:${co}; padding: 3px 10px; border-radius: 20px; font-size: 0.82em; font-weight: 600;">${val}</span>`;
                    } else if (c.key === 'Attendance (%)') {
                        const att = parseFloat(val);
                        const color = att < 75 ? '#dc2626' : att < 85 ? '#f59e0b' : '#16a34a';
                        cell = `<span style="color:${color}; font-weight: 600;">${val}%</span>`;
                    } else if (c.key === 'Recommendation') {
                        cell = `<span style="font-weight: 500; color: var(--primary); font-style: italic;">${val}</span>`;
                    } else {
                        cell = val;
                    }
                    return `<td style="padding: 11px 14px; border-bottom: 1px solid #f1f5f9; white-space: nowrap;">${cell}</td>`;
                }).join('')}
                    <td style="padding: 11px 14px; border-bottom: 1px solid #f1f5f9; white-space: nowrap;">
                    ${row.Grade === 'A+' ?
                        `<button onclick="window.generateDoc('${row.Student_ID}', 'merit')" class="btn-doc-merit" title="Merit Certificate"><i class="fas fa-certificate"></i></button>` : ''
                    }
                    ${(row.Intervention_Priority === 'CRITICAL' || row['Attendance (%)'] < 75) ?
                        `<button onclick="window.generateDoc('${row.Student_ID}', 'risk')" class="btn-doc-risk" title="Intervention Letter"><i class="fas fa-exclamation-circle"></i></button>` : ''}
                    ${(row.Grade !== 'A+' && row.Intervention_Priority !== 'CRITICAL' && row['Attendance (%)'] >= 75) ?
                        `<span style="color:#d1d5db; font-size:0.8em;">No action</span>` : ''
                    }
                    </td>
                </tr>`;
            }).join('');
        }

        // Stats & pagination
        previewRecordCount.textContent = `${total} record${total !== 1 ? 's' : ''} `;
        previewPageInfo.textContent = total > 0 ? `Page ${previewCurrentPage} of ${totalPages} ` : '';
        previewPrev.disabled = previewCurrentPage <= 1;
        previewNext.disabled = previewCurrentPage >= totalPages;
        previewPrev.style.opacity = previewCurrentPage <= 1 ? '0.4' : '1';
        previewNext.style.opacity = previewCurrentPage >= totalPages ? '0.4' : '1';
    }

    // Search filter
    if (previewSearch) {
        previewSearch.addEventListener('input', () => {
            const q = previewSearch.value.toLowerCase().trim();
            previewFilteredRows = previewAllRows.filter(r =>
                (r.Student_Name || '').toLowerCase().includes(q) ||
                (r.Student_ID || '').toLowerCase().includes(q)
            );
            previewCurrentPage = 1;
            renderPreviewTable();
        });
    }

    // Pagination
    if (previewPrev) previewPrev.addEventListener('click', () => { previewCurrentPage--; renderPreviewTable(); });
    if (previewNext) previewNext.addEventListener('click', () => { previewCurrentPage++; renderPreviewTable(); });

    // Open buttons
    if (viewFullBtn) viewFullBtn.addEventListener('click', () => openPreviewModal('full'));
    if (viewRiskBtn) viewRiskBtn.addEventListener('click', () => openPreviewModal('risk'));

    const viewSparkRiskBtn = document.getElementById('view-spark-risk');
    const exportSparkRiskBtn = document.getElementById('export-spark-risk');

    if (viewSparkRiskBtn) viewSparkRiskBtn.addEventListener('click', () => openPreviewModal('risk_spark'));
    if (exportSparkRiskBtn) exportSparkRiskBtn.addEventListener('click', () => {
        window.location.href = '/api/export-csv?type=risk_spark';
    });

    // Close
    if (closeExportPreview) closeExportPreview.addEventListener('click', closePreviewModal);
    exportPreviewModal.addEventListener('click', (e) => { if (e.target === exportPreviewModal) closePreviewModal(); });

    // Initial Load
    fetchStats();
    renderCalendar();
    fetchNotifications();
    fetchMessages();

    // Refresh data periodically (optional "live" feel)
    setInterval(() => {
        fetchNotifications();
        fetchMessages();
    }, 60000); // Check every minute

    // Profile Dropdown Toggle
    const profileToggle = document.getElementById('profileToggle');
    const profileWrapper = document.querySelector('.user-profile-wrapper');

    if (profileToggle && profileWrapper) {
        profileToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            profileWrapper.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!profileWrapper.contains(e.target)) {
                profileWrapper.classList.remove('active');
            }
        });
    }

    // Global Document Generator Trigger
    window.generateDoc = function (studentId, type) {
        const url = `/api/generate-doc?id=${studentId}&type=${type}`;

        // Show a brief toast or loading indicator (optional)
        const btn = event.currentTarget;
        const originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        btn.disabled = true;

        fetch(url)
            .then(response => {
                if (response.ok) return response.blob();
                throw new Error('Generation failed');
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${type === 'merit' ? 'Merit_Certificate' : 'Warning_Letter'}_${studentId}.pdf`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            })
            .catch(err => alert('Failed to generate document: ' + err.message))
            .finally(() => {
                btn.innerHTML = originalContent;
                btn.disabled = false;
            });
    };
});
