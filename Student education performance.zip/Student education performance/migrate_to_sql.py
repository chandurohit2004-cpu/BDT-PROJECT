import sqlite3
import pandas as pd
import os

DATA_PATH = 'cleaned_student_data.csv'
DB_PATH = 'students.db'

def migrate():
    if not os.path.exists(DATA_PATH):
        print(f"Error: {DATA_PATH} not found.")
        return

    # Load CSV
    print(f"Loading data from {DATA_PATH}...")
    df = pd.read_csv(DATA_PATH)

    # Connect to SQLite
    print(f"Connecting to {DB_PATH}...")
    conn = sqlite3.connect(DB_PATH)
    
    # Write to SQL (Create table if not exists)
    # We'll use 'replace' to ensure a clean start for the migration
    print("Migrating data to 'students' table...")
    df.to_sql('students', conn, if_exists='replace', index=False)
    
    # Create an index on Student_Name for faster lookups
    print("Creating index on Student_Name...")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_student_name ON students(Student_Name)")
    
    conn.commit()
    conn.close()
    print("Migration successful! students.db is ready.")

if __name__ == '__main__':
    migrate()
