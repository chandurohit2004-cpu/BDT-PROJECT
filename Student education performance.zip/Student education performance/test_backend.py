import requests
import json

def test_apis():
    base_url = "http://127.0.0.1:5000"
    try:
        print("Testing /api/stats...")
        r_stats = requests.get(f"{base_url}/api/stats")
        print(f"Status: {r_stats.status_code}")
        print(json.dumps(r_stats.json(), indent=2))

        print("\nTesting /api/analytics...")
        r_ana = requests.get(f"{base_url}/api/analytics")
        print(f"Status: {r_ana.status_code}")
        print(json.dumps(r_ana.json(), indent=2))
        
        print("\nTesting /api/heatmap...")
        r_heat = requests.get(f"{base_url}/api/heatmap")
        print(f"Status: {r_heat.status_code}")
        print(json.dumps(r_heat.json(), indent=2))
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_apis()
