import pandas as pd
import os

def check_parquet():
    path = 'student_analytics_gold.parquet'
    if not os.path.exists(path):
        print("Parquet file missing")
        return
    try:
        df = pd.read_parquet(path)
        print(f"Parquet rows: {len(df)}")
        if len(df) > 0:
            print(df.head())
    except Exception as e:
        print(f"Error reading parquet: {e}")

if __name__ == "__main__":
    check_parquet()
