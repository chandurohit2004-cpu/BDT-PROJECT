import os

root = r"c:\Users\Chand\OneDrive\Documents\Student education performance"
for dirpath, dirnames, filenames in os.walk(root):
    for filename in filenames:
        if filename == "students.db":
            path = os.path.join(dirpath, filename)
            size = os.path.getsize(path)
            print(f"Found {path} - Size: {size}")
