import pandas as pd
import os

PARQUET_PATH = "student_analytics_gold.parquet"

print(f"Checking if {PARQUET_PATH} exists...")
if os.path.exists(PARQUET_PATH):
    print("File exists. Attempting to read...")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"Read successful! Records: {len(df)}")
    print("Columns:", df.columns.tolist())
else:
    print("File DOES NOT exist!")
