import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, round as spark_round, lit
import pandas as pd
import sqlite3

# Data Engineering: Medallion Architecture Implementation
# Bronze: raw SQLite data
# Silver: Cleaned and Feature Engineered Data
# Gold: Aggregated and Analytical Parquet data

def run_spark_pipeline():
    # Ensure Spark uses the correct Python executable
    os.environ['PYSPARK_PYTHON'] = sys.executable
    os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

    print("--------------------------------------------------")
    print("STARTING: APACHE SPARK ETL PIPELINE")
    print("--------------------------------------------------")

    # 1. Initialize Spark Session with Windows-specific performance configs
    # We use local[*] to utilize all available CPU cores
    spark = SparkSession.builder \
        .appName("StudentPerformanceAnalytics") \
        .master("local[*]") \
        .config("spark.driver.memory", "2g") \
        .config("spark.sql.shuffle.partitions", "4") \
        .getOrCreate()
    
    # Reduce log noise
    spark.sparkContext.setLogLevel("ERROR")

    try:
        print("STEP 1: Ingesting Bronze Data (SQLite -> Spark)")
        db_path = 'students.db'
        if not os.path.exists(db_path):
            print(f"Error: {db_path} not found. Run migrate_to_sql.py first.")
            return

        # Connect to SQLite and bridge to Spark via Pandas
        conn = sqlite3.connect(db_path)
        pdf = pd.read_sql_query("SELECT * FROM students", conn)
        conn.close()
        
        # Ingest into Spark
        df = spark.createDataFrame(pdf)
        print(f"Status: Ingested {df.count()} student records into Spark.")
        df.printSchema()

        print("STEP 2: Processing Silver Layer (Feature Engineering)")
        
        # Perform Big Data transformations
        df_silver = df.withColumns({
            "Performance_Index": spark_round((col("Internal_Marks") + col("External_Marks")) / 2, 2),
            
            "Academic_Health_Score": spark_round(
                (col("Attendance (%)") * 0.4) + 
                ((col("Internal_Marks") + col("External_Marks")) * 0.5) - 
                (col("Backlogs") * 5), 2
            ),
            
            "Intervention_Priority": when(col("Backlogs") > 2, lit("CRITICAL"))
                                    .when((col("Attendance (%)") < 75) | (col("Backlogs") > 0), lit("MODERATE"))
                                    .otherwise(lit("STABLE"))
        })
        
        silver_count = df_silver.count()
        print(f"Status: Silver DataFrame created with {silver_count} records.")
        df_silver.show(5)

        print("STEP 3: Materializing Gold Layer (Analytical Parquet Store)")
        
        # Windows Workaround: Spark's native Parquet writer requires complex Hadoop permissions.
        # For this local development environment, we use the high-speed Pandas/PyArrow bridge
        # to save the Gold Layer as a Parquet file.
        output_path = "student_analytics_gold.parquet"
        
        print(f"Status: Converting to Parquet via PyArrow...")
        # Convert Spark DF to Pandas and save
        df_silver.toPandas().to_parquet(output_path, index=False)
        
        print(f"Status: Gold Store successfully created at: {output_path}")
        
        # Display a sample of the high-value analytical data
        print("\n--- SAMPLE ANALYTICAL DATA (TOP 5) ---")
        df_silver.select("Student_Name", "Department", "Academic_Health_Score", "Intervention_Priority").show(5)

    except Exception as e:
        print(f"Error: Pipeline Failed: {str(e)}")
    finally:
        spark.stop()
        print("--------------------------------------------------")
        print("DONE: SPARK SESSION CLOSED")

if __name__ == "__main__":
    run_spark_pipeline()
