from influxdb_client import InfluxDBClient

client = InfluxDBClient(url='http://localhost:8086', token='super-secret-spark-token', org='edu-analytics')
query_api = client.query_api()
query = 'from(bucket: "academic_metrics") |> range(start: -24h) |> filter(fn: (r) => r["_measurement"] == "dept_performance") |> filter(fn: (r) => r["_field"] == "marks") |> last()'
tables = query_api.query(query)

print("--- Data in InfluxDB ---")
for table in tables:
    for record in table.records:
        print(f"Dept: {record.values.get('department')}, Value: {record.get_value()}")
