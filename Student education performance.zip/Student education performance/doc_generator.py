from fpdf import FPDF
import datetime
import os
import pandas as pd
import sqlite3

class DocumentGenerator:
    def __init__(self):
        self.logo_path = None # Could add a logo later
        
    def generate_merit_certificate(self, student_name, student_id, department, grade):
        pdf = FPDF(orientation='L', unit='mm', format='A4')
        pdf.add_page()
        
        # Draw Border
        pdf.set_line_width(2)
        pdf.set_draw_color(160, 26, 49) # Primary Maroon
        pdf.rect(10, 10, 277, 190)
        
        pdf.set_line_width(0.5)
        pdf.rect(13, 13, 271, 184)

        # Header
        pdf.set_font('helvetica', 'B', 40)
        pdf.set_text_color(160, 26, 49)
        pdf.ln(30)
        pdf.cell(0, 20, "CERTIFICATE OF EXCELLENCE", ln=True, align='C')
        
        pdf.set_font('helvetica', 'I', 15)
        pdf.set_text_color(100, 100, 100)
        pdf.ln(10)
        pdf.cell(0, 10, "This is to certify that", ln=True, align='C')
        
        # Name
        pdf.set_font('helvetica', 'B', 30)
        pdf.set_text_color(0, 0, 0)
        pdf.ln(10)
        pdf.cell(0, 15, student_name, ln=True, align='C')
        
        # Details
        pdf.set_font('helvetica', '', 14)
        pdf.ln(10)
        msg = f"of Department {department} (ID: {student_id}) has demonstrated outstanding academic performance"
        pdf.cell(0, 10, msg, ln=True, align='C')
        
        pdf.ln(5)
        msg2 = f"and has achieved the distinguished Grade of '{grade}' in the current academic review."
        pdf.cell(0, 10, msg2, ln=True, align='C')
        
        # Footer
        pdf.ln(30)
        pdf.set_font('helvetica', 'B', 12)
        date_str = datetime.datetime.now().strftime("%B %d, %Y")
        
        # Left side: Date
        pdf.set_xy(40, 160)
        pdf.cell(60, 10, f"Date: {date_str}", border='T', align='C')
        
        # Right side: Signature
        pdf.set_xy(190, 160)
        pdf.cell(60, 10, "Dean of Academics", border='T', align='C')
        
        output_dir = "generated_docs"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        filename = f"Merit_{student_id}.pdf"
        full_path = os.path.join(output_dir, filename)
        pdf.output(full_path)
        return full_path

    def generate_risk_letter(self, student_name, student_id, department, att, backlogs, recommendation):
        pdf = FPDF(orientation='P', unit='mm', format='A4')
        pdf.add_page()
        
        # Letterhead Simulation
        pdf.set_font('helvetica', 'B', 16)
        pdf.set_text_color(160, 26, 49)
        pdf.cell(0, 10, "OFFICE OF ACADEMIC MONITORING", ln=True, align='C')
        pdf.set_font('helvetica', '', 10)
        pdf.set_text_color(100, 100, 100)
        pdf.cell(0, 5, "Intelligence-Driven Performance Intervention Unit", ln=True, align='C')
        pdf.ln(10)
        pdf.line(20, 30, 190, 30)
        
        # Body
        pdf.set_text_color(0, 0, 0)
        pdf.set_font('helvetica', '', 11)
        pdf.ln(10)
        
        date_str = datetime.datetime.now().strftime("%B %d, %Y")
        pdf.cell(0, 10, f"Date: {date_str}", ln=True)
        pdf.ln(5)
        
        pdf.cell(0, 10, f"To: {student_name} ({student_id})", ln=True)
        pdf.cell(0, 5, f"Department: {department}", ln=True)
        pdf.ln(10)
        
        pdf.set_font('helvetica', 'B', 12)
        pdf.cell(0, 10, "Subject: FORMAL ACADEMIC PERFORMANCE INTERVENTION", ln=True)
        pdf.ln(5)
        
        pdf.set_font('helvetica', '', 11)
        body_text = (
            f"Dear {student_name},\n\n"
            "Our automated Big Data analysis engine has conducted a review of your current academic metrics. "
            "Based on our findings, your current trajectory indicates a significant risk to your semester completion.\n\n"
            "KEY METRICS DETECTED:\n"
            f"- Current Attendance: {att}%\n"
            f"- Active Backlogs: {backlogs}\n\n"
            "REQUIRED INTERVENTION (AI RECOMMENDATION):\n"
        )
        pdf.multi_cell(0, 6, body_text)
        
        # The Spark Recommendation in bold box
        pdf.set_fill_color(255, 241, 242)
        pdf.set_font('helvetica', 'B', 12)
        pdf.set_text_color(153, 27, 27)
        pdf.ln(5)
        pdf.multi_cell(0, 10, recommendation.upper(), border=1, align='C', fill=True)
        
        pdf.ln(10)
        pdf.set_font('helvetica', '', 11)
        pdf.set_text_color(0, 0, 0)
        closing = (
            "Please acknowledge this notice by meeting with your Head of Department within 48 hours. "
            "Failure to improve these metrics may result in academic probation or ineligibility for final examinations."
        )
        pdf.multi_cell(0, 6, closing)
        
        pdf.ln(20)
        pdf.cell(0, 10, "Sincerely,", ln=True)
        pdf.set_font('helvetica', 'B', 11)
        pdf.cell(0, 5, "Director of Student Success", ln=True)
        pdf.cell(0, 5, "Academic Intelligence Division", ln=True)
        
        output_dir = "generated_docs"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        filename = f"Warning_{student_id}.pdf"
        full_path = os.path.join(output_dir, filename)
        pdf.output(full_path)
        return full_path

# Helper to fetch data for generator
def fetch_and_generate(student_id, doc_type):
    conn = sqlite3.connect('students.db')
    conn.row_factory = sqlite3.Row
    row = conn.execute('SELECT * FROM students WHERE Student_ID = ?', (student_id,)).fetchone()
    conn.close()
    
    if not row:
        return None
    
    gen = DocumentGenerator()
    
    if doc_type == 'merit':
        return gen.generate_merit_certificate(row['Student_Name'], row['Student_ID'], row['Department'], row['Grade'])
    
    elif doc_type == 'risk':
        # Try to find recommendation in Spark report
        recommendation = "Immediate faculty consultation and mandatory remedial coaching."
        report_path = 'spark_at_risk_intelligence.csv'
        if os.path.exists(report_path):
            try:
                df = pd.read_csv(report_path)
                match = df[df['Student_ID'] == student_id]
                if not match.empty:
                    recommendation = match.iloc[0]['Recommendation']
            except:
                pass
                
        return gen.generate_risk_letter(row['Student_Name'], row['Student_ID'], row['Department'], row['Attendance (%)'], row['Backlogs'], recommendation)
    
    return None
