import pandas as pd
from sklearn.preprocessing import LabelEncoder
import pickle

def transform_data(input_file, output_csv, output_metadata):
    print(f"Loading cleaned data: {input_file}")
    df = pd.read_csv(input_file)
    
    # 1. Feature Selection: Focus on criteria requested by the user
    features_to_keep = ['Attendance (%)', 'Internal_Marks', 'External_Marks', 'Backlogs']
    df_model = df[features_to_keep]
    
    # We want to predict Grade, so Grade is our target (y)
    y = df['Grade']
    
    # 2. No categorical encoding needed anymore as all features are numeric
    df_encoded = df_model.copy()
    
    # 3. Encode Target
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    
    # Save Label Encoder for later use (to map numbers back to grades)
    metadata = {
        'label_encoder': le,
        'features': df_encoded.columns.tolist(),
        'target_classes': le.classes_.tolist()
    }
    with open(output_metadata, 'wb') as f:
        pickle.dump(metadata, f)
    
    # Combine features and target for saving
    df_final = df_encoded.copy()
    df_final['Target_Grade'] = y_encoded
    
    df_final.to_csv(output_csv, index=False)
    print(f"Transformed data saved to: {output_csv}")
    print(f"Metadata saved to: {output_metadata}")
    print(f"Feature set: {df_final.columns.tolist()}")
    
    return df_final

if __name__ == "__main__":
    transform_data('cleaned_student_data.csv', 'transformed_student_data.csv', 'transformation_metadata.pkl')
