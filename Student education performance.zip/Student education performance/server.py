from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from functools import wraps

from flask_cors import CORS
import pandas as pd
import pickle
import numpy as np
import os
import sqlite3
from doc_generator import fetch_and_generate
from flask import send_file
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'default_development_super_secret_key')
CORS(app)

# --- Authentication Setup ---
USER_CREDENTIALS = {
    'admin': 'password123'
}

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            session['logged_in'] = True
            session['username'] = username
            next_url = request.args.get('next')
            return redirect(next_url or url_for('index'))
        else:
            error = 'Invalid username or password. Please try again.'
            
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('login'))
# --------------------------

# Load resources
DB_PATH = 'students.db'

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Access columns by name
    return conn


@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/api/user-info')
def get_user_info():
    return jsonify({
        "name": "Standard User",
        "role": "admin",
        "username": "guest"
    })

@app.route('/api/stats')
@login_required
def get_stats():
    # Priority 1: Use Spark-generated Parquet (Gold Layer)
    parquet_path = 'student_analytics_gold.parquet'
    if os.path.exists(parquet_path):
        try:
            # Use pandas to read the Spark Parquet directory
            df = pd.read_parquet(parquet_path)
            if df.empty:
                raise ValueError("Parquet file is empty")
            
            total = len(df)
            avg_att = float(df['Attendance (%)'].mean())
            pass_count = int(len(df[df['Grade'] != 'F']))
            at_risk = int(len(df[df['Grade'].isin(['D', 'F'])]))
            
            # Department averages from Parquet
            dept_avgs = df.groupby('Department')['Total_Marks'].mean()
            dept_stats = {str(dept): round(float(avg), 1) for dept, avg in dept_avgs.items()}

            return jsonify({
                "total_students": total,
                "avg_attendance": round(avg_att, 1),
                "pass_rate": round((pass_count / total * 100) if total > 0 else 0, 1),
                "at_risk_count": at_risk,
                "dept_stats": dept_stats,
                "data_source": "Enterprise Spark (Parquet)"
            })
        except Exception as e:
            print(f"Spark Stats Error: {e}")

    # Priority 2: Fallback to SQLite
    conn = get_db_connection()
    try:
        total = conn.execute('SELECT COUNT(*) FROM students').fetchone()[0]
        avg_att = conn.execute('SELECT AVG("Attendance (%)") FROM students').fetchone()[0]
        pass_count = conn.execute('SELECT COUNT(*) FROM students WHERE Grade != "F"').fetchone()[0]
        at_risk = conn.execute('SELECT COUNT(*) FROM students WHERE Grade IN ("D", "F")').fetchone()[0]
        depts = conn.execute('SELECT Department, AVG(Total_Marks) as avg_marks FROM students GROUP BY Department').fetchall()
        dept_stats = {row['Department']: round(row['avg_marks'], 1) for row in depts}

        return jsonify({
            "total_students": total,
            "avg_attendance": round(avg_att or 0, 1),
            "pass_rate": round((pass_count / total * 100) if total > 0 else 0, 1),
            "at_risk_count": at_risk,
            "dept_stats": dept_stats,
            "data_source": "SQLite (Transactional)"
        })
    finally:
        conn.close()

@app.route('/api/students')
@login_required
def get_students():
    search_query = request.args.get('q', '').lower()
    conn = get_db_connection()
    try:
        if search_query:
            query = """
                SELECT Student_ID, Student_Name, "Attendance (%)", Internal_Marks, External_Marks, Backlogs, Grade 
                FROM students 
                WHERE LOWER(Student_Name) LIKE ? OR LOWER(Student_ID) LIKE ?
                LIMIT 10
            """
            rows = conn.execute(query, (f'%{search_query}%', f'%{search_query}%')).fetchall()
        else:
            rows = conn.execute('SELECT * FROM students LIMIT 10').fetchall()
        
        student_list = [dict(row) for row in rows]
        return jsonify(student_list)
    finally:
        conn.close()

@app.route('/api/heatmap-data')
@login_required
def get_heatmap_data():
    parquet_path = 'student_analytics_gold.parquet'
    if os.path.exists(parquet_path):
        try:
            df = pd.read_parquet(parquet_path)
            
            # Define Attendance Brackets
            bins = [0, 60, 70, 80, 90, 100]
            labels = ['<60%', '60-70%', '70-80%', '80-90%', '90-100%']
            df['Attendance_Bracket'] = pd.cut(df['Attendance (%)'], bins=bins, labels=labels, right=False)
            
            # Create a cross-tabulation of Grades and Attendance Brackets
            heatmap_data = pd.crosstab(df['Grade'], df['Attendance_Bracket'])
            
            # Format for ApexCharts: series = [{name: 'Grade A', data: [{x: '<60%', y: 5}, ...]}, ...]
            series = []
            grades_order = ['A+', 'A', 'B+', 'B', 'C', 'D', 'F']
            
            for grade in grades_order:
                if grade in heatmap_data.index:
                    data_points = []
                    for bracket in labels:
                        count = int(heatmap_data.loc[grade, bracket]) if bracket in heatmap_data.columns else 0
                        data_points.append({"x": bracket, "y": count})
                    series.append({"name": f"Grade {grade}", "data": data_points})
            
            return jsonify({"series": series})
        except Exception as e:
            print(f"Heatmap Data Error: {e}")
            return jsonify({"error": str(e)}), 500
    return jsonify({"error": "Data source not found"}), 404

@app.route('/api/burnout')
@login_required
def get_burnout_data():
    parquet_path = 'student_analytics_gold.parquet'
    if os.path.exists(parquet_path):
        try:
            df = pd.read_parquet(parquet_path)
            
            # Burnout Risk Calculation Logic: 
            # High Backlogs (40%) + Low Attendance (40%) + Low Internal Marks (20%)
            df['Burnout_Score'] = (
                (df['Backlogs'] * 15).clip(0, 40) + 
                ((100 - df['Attendance (%)']) * 0.4) + 
                ((40 - df['Internal_Marks']) * 0.5).clip(0, 20)
            )
            
            # Category distribution
            risk_dist = {
                "Low": int(len(df[df['Burnout_Score'] < 30])),
                "Moderate": int(len(df[(df['Burnout_Score'] >= 30) & (df['Burnout_Score'] < 60)])),
                "High": int(len(df[df['Burnout_Score'] >= 60]))
            }
            
            # Top 10 High Burnout Students for Watchlist
            watchlist = df[df['Burnout_Score'] > 50].sort_values(by='Burnout_Score', ascending=False).head(10)
            watchlist_data = watchlist[['Student_ID', 'Student_Name', 'Department', 'Burnout_Score']].to_dict(orient='records')
            
            return jsonify({
                "risk_distribution": risk_dist,
                "watchlist": watchlist_data,
                "avg_burnout": round(float(df['Burnout_Score'].mean()), 1)
            })
        except Exception as e:
            print(f"Burnout API Error: {e}")
            return jsonify({"error": str(e)}), 500
    return jsonify({"error": "Data source not found"}), 404
def get_analytics():
    parquet_path = 'student_analytics_gold.parquet'
    if os.path.exists(parquet_path):
        try:
            df = pd.read_parquet(parquet_path)
            if df.empty:
                raise ValueError("Parquet file is empty")
            
            # 1. Grade Distribution
            gd = df['Grade'].value_counts().to_dict()
            grade_dist = {str(k): int(v) for k, v in gd.items()}
            
            # 2. Dept Stats
            dept_grouped = df.groupby('Department').agg({'Attendance (%)': 'mean', 'Total_Marks': 'mean'})
            dept_stats = {str(dept): {
                'Attendance (%)': round(float(row['Attendance (%)']), 1),
                'Total_Marks': round(float(row['Total_Marks']), 1)
            } for dept, row in dept_grouped.iterrows()}
            
            # 3. Backlogs
            bd = df['Backlogs'].value_counts().to_dict()
            backlog_dist = {str(k): int(v) for k, v in bd.items()}
            
            total = int(len(df))

            return jsonify({
                "grade_distribution": grade_dist,
                "department_stats": dept_stats,
                "backlog_distribution": backlog_dist,
                "total_count": total,
                "data_source": "Enterprise Spark (Parquet)"
            })
        except Exception as e:
            print(f"Spark Analytics Error: {e}")

    # Fallback to SQLite
    conn = get_db_connection()
    try:
        # 1. Grade Distribution
        grades = conn.execute('SELECT Grade, COUNT(*) as count FROM students GROUP BY Grade').fetchall()
        grade_dist = {row['Grade']: row['count'] for row in grades}
        
        # 2. Dept Stats
        dept_rows = conn.execute('''
            SELECT Department, AVG("Attendance (%)") as avg_att, AVG(Total_Marks) as avg_marks 
            FROM students GROUP BY Department
        ''').fetchall()
        dept_stats = {row['Department']: {
            'Attendance (%)': round(row['avg_att'], 1),
            'Total_Marks': round(row['avg_marks'], 1)
        } for row in dept_rows}
        
        # 3. Backlogs
        backlog_rows = conn.execute('SELECT Backlogs, COUNT(*) as count FROM students GROUP BY Backlogs').fetchall()
        backlog_dist = {row['Backlogs']: row['count'] for row in backlog_rows}
        
        total = conn.execute('SELECT COUNT(*) FROM students').fetchone()[0]

        return jsonify({
            "grade_distribution": grade_dist,
            "department_stats": dept_stats,
            "backlog_distribution": backlog_dist,
            "total_count": total,
            "data_source": "SQLite (Transactional)"
        })
    finally:
        conn.close()

@app.route('/api/add-student', methods=['POST'])
@login_required
def add_student():
    data = request.json
    required = ['Student_Name', 'Student_ID', 'Department', 'Internal_Marks', 'External_Marks', 'Attendance (%)', 'Backlogs']
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing field: {field}"}), 400
            
    conn = get_db_connection()
    try:
        total_marks = data['Internal_Marks'] + data['External_Marks']
        
        if total_marks >= 90: grade = 'A+'
        elif total_marks >= 80: grade = 'A'
        elif total_marks >= 70: grade = 'B+'
        elif total_marks >= 60: grade = 'B'
        elif total_marks >= 50: grade = 'C'
        else: grade = 'D'
        
        # Align with current database schema (15 columns)
        # Columns: Student_ID, Gender, Department, Year, Semester, Attendance (%), Internal_Marks, External_Marks, Total_Marks, Grade, CGPA, Backlogs, Scholar_Type, Placement_Status, Student_Name
        
        gender = "M"
        year = 1
        semester = 1
        cgpa = round(total_marks / 10.0, 2)
        scholar_type = "Day Scholar"
        placement_status = "Not Placed"

        conn.execute('''
            INSERT INTO students (
                Student_ID, Gender, Department, Year, Semester, 
                "Attendance (%)", Internal_Marks, External_Marks, Total_Marks, 
                Grade, CGPA, Backlogs, Scholar_Type, Placement_Status, Student_Name
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['Student_ID'], gender, data['Department'], year, semester,
            data['Attendance (%)'], data['Internal_Marks'], data['External_Marks'], total_marks,
            grade, cgpa, data['Backlogs'], scholar_type, placement_status, data['Student_Name']
        ))
        
        conn.commit()
        return jsonify({"status": "Success", "message": "Student added successfully permanently"})
    except Exception as e:
        print(f"Add Student SQL Error: {e}")
        return jsonify({"error": str(e)}), 400
    finally:
        conn.close()

@app.route('/api/notifications')
@login_required
def get_notifications():
    conn = get_db_connection()
    try:
        # 1. Detect low attendance
        low_att = conn.execute('SELECT Student_Name, "Attendance (%)" FROM students WHERE "Attendance (%)" < 75 LIMIT 3').fetchall()
        
        # 2. Detect failing grades
        low_perf = conn.execute('SELECT Student_Name, Grade FROM students WHERE Grade IN ("D", "F") LIMIT 3').fetchall()
        
        notifs = []
        for row in low_att:
            notifs.append({
                "type": "risk",
                "title": "Low Attendance Alert",
                "message": f"{row['Student_Name']} dropped to {row['Attendance (%)']}% attendance.",
                "time": "Just now",
                "icon": "fa-exclamation-triangle"
            })
            
        for row in low_perf:
            notifs.append({
                "type": "alert",
                "title": "Performance Warning",
                "message": f"{row['Student_Name']} projected to get grade: {row['Grade']}.",
                "time": "1 hour ago",
                "icon": "fa-chart-line"
            })
            
        # Add a placeholder event notification
        notifs.append({
            "type": "event",
            "title": "Academic Review",
            "message": "Faculty meeting scheduled for tomorrow at 10:00 AM.",
            "time": "2 hours ago",
            "icon": "fa-calendar-check"
        })

        return jsonify(notifs)
    finally:
        conn.close()

@app.route('/api/messages')
@login_required
def get_messages():
    # Mock data for faculty messages
    messages = [
        {
            "sender": "Dr. Sarah Johnson",
            "avatar": "https://ui-avatars.com/api/?name=Sarah+Johnson&background=f3e8ff&color=9333ea",
            "subject": "IT Dept Results",
            "preview": "I've uploaded the internal marks for the 3rd semester...",
            "time": "10 mins ago"
        },
        {
            "sender": "Prof. Amit Verma",
            "avatar": "https://ui-avatars.com/api/?name=Amit+Verma&background=dcfce7&color=16a34a",
            "subject": "Lab Equipment",
            "preview": "We need additional resources for the CSE AI lab...",
            "time": "Yesterday"
        }
    ]
    return jsonify(messages)

@app.route('/api/upload-csv', methods=['POST'])
@login_required
def upload_csv():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    try:
        df_new = pd.read_csv(file)
        # Basic validation: ensure required columns exist
        required = ['Student_Name', 'Student_ID', 'Department', 'Internal_Marks', 'External_Marks', 'Attendance (%)', 'Backlogs']
        for col in required:
            if col not in df_new.columns:
                return jsonify({"error": f"Missing column in CSV: {col}"}), 400
        
        conn = get_db_connection()
        count = 0
        for _, row in df_new.iterrows():
            # Calculate Total Marks and Grade
            tm = row['Internal_Marks'] + row['External_Marks']
            if tm >= 90: grade = 'A+'
            elif tm >= 80: grade = 'A'
            elif tm >= 70: grade = 'B+'
            elif tm >= 60: grade = 'B'
            elif tm >= 50: grade = 'C'
            else: grade = 'D'
            
            # Align with current database schema
            gender = row.get('Gender', 'M')
            year = row.get('Year', 1)
            semester = row.get('Semester', 1)
            cgpa = row.get('CGPA', round(tm / 10.0, 2))
            scholar_type = row.get('Scholar_Type', 'Day Scholar')
            placement_status = row.get('Placement_Status', 'Not Placed')

            conn.execute('''
                INSERT OR REPLACE INTO students (
                    Student_ID, Gender, Department, Year, Semester, 
                    "Attendance (%)", Internal_Marks, External_Marks, Total_Marks, 
                    Grade, CGPA, Backlogs, Scholar_Type, Placement_Status, Student_Name
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                row['Student_ID'], gender, row['Department'], year, semester,
                row['Attendance (%)'], row['Internal_Marks'], row['External_Marks'], tm,
                grade, cgpa, row['Backlogs'], scholar_type, placement_status, row['Student_Name']
            ))
            count += 1
            
        conn.commit()
        conn.close()
        return jsonify({"status": "Success", "count": count})
    except Exception as e:
        print(f"CSV Upload Error: {e}")
        return jsonify({"error": str(e)}), 400

@app.route('/api/preview-students')
@login_required
def preview_students():
    export_type = request.args.get('type', 'full')
    
    # Check if we should use Spark intelligence for risk preview
    if export_type == 'risk_spark':
        report_path = 'spark_at_risk_intelligence.csv'
        if os.path.exists(report_path):
            try:
                df = pd.read_csv(report_path)
                # Map column names for UI consistency if needed
                students = df.to_dict('records')
                return jsonify({'students': students, 'total': len(students), 'source': 'Apache Spark'})
            except Exception as e:
                print(f"Error reading Spark report: {e}")

    # Fallback to SQLite
    conn = get_db_connection()
    try:
        if export_type == 'risk' or export_type == 'risk_spark':
            query = 'SELECT Student_ID, Student_Name, Department, "Attendance (%)", Internal_Marks, External_Marks, Total_Marks, Backlogs, Grade FROM students WHERE "Attendance (%)" < 75 ORDER BY "Attendance (%)" ASC'
        else:
            query = 'SELECT Student_ID, Student_Name, Department, "Attendance (%)", Internal_Marks, External_Marks, Total_Marks, Backlogs, Grade FROM students ORDER BY Student_Name ASC'
        
        rows = conn.execute(query).fetchall()
        students = [dict(row) for row in rows]
        return jsonify({'students': students, 'total': len(students), 'source': 'SQLite'})
    finally:
        conn.close()

@app.route('/api/export-csv')
@login_required
def export_csv():
    export_type = request.args.get('type', 'full')
    
    # Priority: Spark-generated tactical report
    if export_type == 'risk_spark':
        report_path = 'spark_at_risk_intelligence.csv'
        if os.path.exists(report_path):
            from flask import send_file
            return send_file(report_path, as_attachment=True, download_name="spark_at_risk_intelligence.csv")

    conn = get_db_connection()
    try:
        if export_type == 'risk':
            query = 'SELECT * FROM students WHERE "Attendance (%)" < 75'
        else:
            query = 'SELECT * FROM students'
            
        df_export = pd.read_sql_query(query, conn)
        
        # Create CSV in memory
        from io import StringIO
        output = StringIO()
        df_export.to_csv(output, index=False)
        
        from flask import Response
        filename = f"student_export_{export_type}.csv"
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-disposition": f"attachment; filename={filename}"}
        )
    finally:
        conn.close()

@app.route('/api/generate-doc')
@login_required
def generate_doc():
    student_id = request.args.get('id')
    doc_type = request.args.get('type') # 'merit' or 'risk'
    
    if not student_id or not doc_type:
        return jsonify({"error": "Missing parameters"}), 400
        
    try:
        pdf_path = fetch_and_generate(student_id, doc_type)
        if pdf_path and os.path.exists(pdf_path):
            return send_file(pdf_path, as_attachment=True)
        else:
            return jsonify({"error": "Failed to generate document"}), 500
    except Exception as e:
        print(f"Doc Generation Error: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("\n" + "="*50)
    print("STUDENT PERFORMANCE DASHBOARD STARTING...")
    print("URL: http://127.0.0.1:5000")
    print("="*50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5001)
