import sqlite3

def check_db():
    try:
        conn = sqlite3.connect('students.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        count = cursor.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        print(f"Total students in DB: {count}")
        if count > 0:
            sample = cursor.execute("SELECT * FROM students LIMIT 5").fetchall()
            for row in sample:
                print(dict(row))
        conn.close()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_db()
