from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

TOKEN = "super-secret-spark-token"
ORG = "edu-analytics"
BUCKET = "academic_metrics"
URL = "http://localhost:8086"

print("Attempting to connect to InfluxDB...")
client = InfluxDBClient(url=URL, token=TOKEN, org=ORG)
write_api = client.write_api(write_options=SYNCHRONOUS)

print("Attempting to write a test point...")
point = Point("test_measurement").field("value", 1.0)
write_api.write(BUCKET, ORG, point)

print("Write successful!")
client.close()
