from influxdb_client import InfluxDBClient
import pandas as pd

TOKEN = "super-secret-spark-token"
ORG = "edu-analytics"
BUCKET = "academic_metrics"
URL = "http://localhost:8086"

client = InfluxDBClient(url=URL, token=TOKEN, org=ORG)

query = f'''
from(bucket: "{BUCKET}")
  |> range(start: -1h)
  |> filter(fn: (r) => r["_measurement"] == "dept_performance")
  |> filter(fn: (r) => r["_field"] == "marks")
  |> last()
'''

tables = client.query_api().query(query, org=ORG)

print("--- Data in InfluxDB for dept_performance ---")
found = False
for table in tables:
    for record in table.records:
        found = True
        print(f"Dept: {record['department']}, Marks: {record.get_value()}")

if not found:
    print("NO DATA FOUND in the last 1 hour!")

client.close()
