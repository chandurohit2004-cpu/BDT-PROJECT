import pandas as pd
df = pd.read_parquet('student_analytics_gold.parquet')
print(df.columns.tolist())
