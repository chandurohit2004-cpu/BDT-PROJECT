import requests

url = "http://localhost:5001/api/add-student"
data = {
    "Student_Name": "Test Student",
    "Student_ID": "T1001",
    "Department": "CSE",
    "Internal_Marks": 25,
    "External_Marks": 45,
    "Attendance (%)": 85,
    "Backlogs": 0
}

# Need to login first or use a session if login is required
# Since I'm running this on the same machine, I'll check if I can bypass or if I need to send login credentials
# server.py has @login_required. Let's try to login first.

session = requests.Session()
login_url = "http://localhost:5001/login"
login_data = {"username": "admin", "password": "password123"}
session.post(login_url, data=login_data)

response = session.post(url, json=data)
print(f"Status Code: {response.status_code}")
print(f"Response: {response.json()}")
