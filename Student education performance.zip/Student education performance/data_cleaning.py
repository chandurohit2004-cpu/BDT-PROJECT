import pandas as pd
import numpy as np

def clean_data(input_file, output_file):
    print(f"Loading dataset: {input_file}")
    df = pd.read_excel(input_file, sheet_name='Student_Data')
    
    # 1. Check for duplicates
    initial_rows = len(df)
    df.drop_duplicates(inplace=True)
    dropped_duplicates = initial_rows - len(df)
    print(f"Removed {dropped_duplicates} duplicate records.")
    
    # 2. Check for missing values
    missing_values = df.isnull().sum()
    print("\nMissing values before cleaning:")
    print(missing_values[missing_values > 0])
    
    # Handling missing values (using median for numeric and mode for categorical)
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].median())
            
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].mode()[0])
            
    # 3. Basic Validation
    # Ensure Attendance is between 0 and 100
    df['Attendance (%)'] = df['Attendance (%)'].clip(0, 100)
    
    # Ensure Backlogs is non-negative
    df['Backlogs'] = df['Backlogs'].apply(lambda x: max(0, x))
    
    # 4. Data Enrichment: Add Student Names
    student_names = [
        "Aarav Sharma", "Aditi Rao", "Akash Gupta", "Ananya Singh", "Arjun Verma",
        "Bhavna Kapoor", "Chirag Malhotra", "Deepika Padukone", "Eshan Khan", "Farhan Akhtar",
        "Gauri Shinde", "Hardik Patel", "Ishita Dutta", "Jatin Soni", "Kavya Iyer",
        "Lucky Ali", "Meera Nair", "Nikhil Kumar", "Ojaswi Joshi", "Pooja Hegde",
        "Qasim Sheikh", "Rohan Mehra", "Sanya Malhotra", "Tanishq Abraham", "Urvashi Rautela",
        "Varun Dhawan", "Waseem Rizvi", "Xavier Gonsalves", "Yash Chopra", "Zoya Akhtar",
        "Abhay Deol", "Bipasha Basu", "Chetan Bhagat", "Dia Mirza", "Emraan Hashmi",
        "Freida Pinto", "Govinda Ahuja", "Huma Qureshi", "Imran Khan", "Jacqueline Fernandez",
        "Karan Johar", "Lara Dutta", "Manoj Bajpayee", "Neha Dhupia", "Om Puri",
        "Priyanka Chopra", "Ranbir Kapoor", "Sonam Kapoor", "Tiger Shroff", "Uday Chopra",
        "Vidya Balan", "Vivek Oberoi", "Waheeda Rehman", "Yami Gautam", "Zayed Khan",
        "Aishwarya Rai", "Bobby Deol", "Chitrangada Singh", "Dhanush Raja", "Esha Gupta",
        "Fardeen Khan", "Genelia D'Souza", "Harshvardhan Kapoor", "Ileana D'Cruz", "John Abraham",
        "Kangana Ranaut", "Lucky Ali", "Mallika Sherawat", "Nawazuddin Siddiqui", "Onir",
        "Prachi Desai", "Rajkummar Rao", "Shriya Saran", "Tabu Hashmi", "Urmila Matondkar",
        "Vidyut Jammwal", "Wajid Khan", "Xenia Ali", "Yashasvi Jaiswal", "Zubeen Garg",
        "Amitabh Bachchan", "Bhumi Pednekar", "Carry Minati", "Disha Patani", "Evelyn Sharma",
        "Fatima Sana Shaikh", "Gajraj Rao", "Hina Khan", "Irfan Pathan", "Juhi Chawla",
        "Kriti Sanon", "Lata Mangeshkar", "Madhuri Dixit", "Naseeruddin Shah", "Pankaj Tripathi",
        "Rani Mukerji", "Sridevi Kapoor", "Tamannaah Bhatia", "Ushoshi Sengupta", "Vijay Sethupathi"
    ]
    
    # Repeat names if dataset is larger than the list
    if len(df) > len(student_names):
        student_names = (student_names * (len(df) // len(student_names) + 1))[:len(df)]
    else:
        student_names = student_names[:len(df)]
        
    df['Student_Name'] = student_names
    
    # 5. Save cleaned data
    df.to_csv(output_file, index=False)
    print(f"\nCleaned data saved to: {output_file}")
    print(f"Final record count: {len(df)}")
    
    return df

if __name__ == "__main__":
    input_xlsx = 'Student_Report_100_With_Backlogs_Charts.xlsx'
    output_csv = 'cleaned_student_data.csv'
    clean_data(input_xlsx, output_csv)
