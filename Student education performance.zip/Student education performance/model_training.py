import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import classification_report, accuracy_score
import matplotlib.pyplot as plt
import pickle

def train_model(input_file, model_output_file):
    print(f"Loading transformed data: {input_file}")
    df = pd.read_csv(input_file)
    
    # Separate features and target
    X = df.drop(columns=['Target_Grade'])
    y = df['Target_Grade']
    
    # Split into train and test sets (80/20)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize and train Decision Tree
    # Setting max_depth to prevent overfitting as per plan
    clf = DecisionTreeClassifier(max_depth=5, random_state=42)
    clf.fit(X_train, y_train)
    
    # Make predictions
    y_pred = clf.predict(X_test)
    
    # Evaluation
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\nModel Accuracy: {accuracy:.2f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Save the model
    with open(model_output_file, 'wb') as f:
        pickle.dump(clf, f)
    print(f"Model saved to: {model_output_file}")
    
    # Visualize the tree (Save as image)
    plt.figure(figsize=(20,10))
    plot_tree(clf, feature_names=X.columns, filled=True, rounded=True)
    plt.savefig('decision_tree_visualization.png')
    print("Decision Tree visualization saved as 'decision_tree_visualization.png'")
    
    return clf

if __name__ == "__main__":
    train_model('transformed_student_data.csv', 'student_performance_model.pkl')
