import csv
import random

first_names = ["Aarav", "Aditi", "Akash", "Ananya", "Arjun", "Bhavna", "Chirag", "Deepika", "Eshan", "Farhan", "Gauri", "Hardik", "Ishita", "Jatin", "Kavya", "Lucky", "Meera", "Nikhil", "Ojaswi", "Pooja", "Qasim", "Rohan", "Sanya", "Tanishq", "Urvashi", "Varun", "Waseem", "Xavier", "Yash", "Zoya", "Abhay", "Bipasha", "Chetan", "Dia", "Emraan", "Freida", "Govinda", "Huma", "Imran", "Jacqueline", "Karan", "Lara", "Manoj", "Neha", "Om", "Priyanka", "Ranbir", "Sonam", "Tiger", "Uday", "Vidya"]
last_names = ["Sharma", "Rao", "Gupta", "Singh", "Verma", "Kapoor", "Malhotra", "Padukone", "Khan", "Akhtar", "Shinde", "Patel", "Dutta", "Soni", "Iyer", "Ali", "Nair", "Kumar", "Joshi", "Hegde", "Sheikh", "Mehra", "Abraham", "Rautela", "Dhawan", "Rizvi", "Gonsalves", "Chopra", "Deol", "Basu", "Bhagat", "Mirza", "Hashmi", "Pinto", "Ahuja", "Qureshi", "Fernandez", "Johar"]

departments = ["CSE", "IT", "ME", "CIVIL", "ECE", "EEE"]

with open("cleaned_student_data.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["Student_ID", "Gender", "Department", "Year", "Semester", "Attendance (%)", "Internal_Marks", "External_Marks", "Total_Marks", "Grade", "CGPA", "Backlogs", "Scholar_Type", "Placement_Status", "Student_Name"])
    
    for i in range(1, 1001):
        s_id = f"S{i:03d}"
        gender = random.choice(["M", "F"])
        dept = random.choice(departments)
        year = random.randint(1, 4)
        semester = year * 2 if random.choice([True, False]) else (year * 2) - 1
        
        # Determine risk profile randomly to make data realistic
        profile = random.random()
        if profile < 0.15: # High risk (15%)
            attendance = random.randint(40, 65)
            internal = random.randint(5, 12)
            external = random.randint(15, 30)
            backlogs = random.randint(3, 5)
        elif profile < 0.70: # Moderate / Average (55%)
            attendance = random.randint(66, 85)
            internal = random.randint(15, 22)
            external = random.randint(30, 45)
            backlogs = random.randint(0, 2)
        else: # High performer (30%)
            attendance = random.randint(86, 100)
            internal = random.randint(25, 30)
            external = random.randint(50, 65)
            backlogs = 0
            
        total = internal + external
        if total >= 90: grade = "O"
        elif total >= 80: grade = "A+"
        elif total >= 70: grade = "A"
        elif total >= 60: grade = "B+"
        elif total >= 50: grade = "B"
        elif total >= 45: grade = "C"
        elif total >= 40: grade = "D"
        else: grade = "F"
        
        cgpa = round(total / 10.0 + random.uniform(-0.5, 0.5), 2)
        if cgpa > 10.0: cgpa = 10.0
        
        scholar = random.choice(["Day Scholar", "Hostel"])
        placed = "Placed" if (year == 4 and total > 70 and backlogs == 0) else "Not Placed"
        if year != 4: placed = "Not Placed"
        
        name = f"{random.choice(first_names)} {random.choice(last_names)}"
        
        writer.writerow([s_id, gender, dept, year, semester, attendance, internal, external, total, grade, cgpa, backlogs, scholar, placed, name])

print("Successfully generated 1000 student records into cleaned_student_data.csv!")
