import json
import os

file_path = "c:\\Users\\Chand\\OneDrive\\Documents\\Student education performance\\grafana\\provisioning\\dashboards\\student_dashboard.json"

new_panel = {
  "datasource": {
    "type": "influxdb",
    "uid": "Student_Metrics_Source"
  },
  "fieldConfig": {
    "defaults": {
      "custom": {
        "lineWidth": 0,
        "fillOpacity": 100,
        "gradientMode": "none",
        "axisPlacement": "auto",
        "axisLabel": "",
        "axisColorMode": "text",
        "scaleDistribution": {
          "type": "linear"
        },
        "axisCenteredZero": False,
        "hideFrom": {
          "tooltip": False,
          "viz": False,
          "legend": False
        },
        "thresholdsStyle": {
          "mode": "off"
        }
      },
      "color": {
        "mode": "fixed",
        "fixedColor": "#a01a31"
      },
      "mappings": [],
      "thresholds": {
        "mode": "absolute",
        "steps": [
          {
            "value": None,
            "color": "green"
          },
          {
            "value": 80,
            "color": "red"
          }
        ]
      },
      "max": 100,
      "min": 0,
      "unit": "short"
    },
    "overrides": []
  },
  "gridPos": {
    "h": 10,
    "w": 12,
    "x": 0,
    "y": 0
  },
  "id": 2,
  "options": {
    "orientation": "vertical",
    "xTickLabelRotation": 0,
    "xTickLabelSpacing": 0,
    "showValue": "always",
    "stacking": "none",
    "groupWidth": 0.7,
    "barWidth": 0.8,
    "barRadius": 0,
    "fullHighlight": False,
    "tooltip": {
      "mode": "single",
      "sort": "none"
    },
    "legend": {
      "showLegend": True,
      "displayMode": "list",
      "placement": "top",
      "calcs": []
    },
    "xField": "Department"
  },
  "targets": [
    {
      "query": "from(bucket: \"academic_metrics\") |> range(start: -24h) |> filter(fn: (r) => r[\"_measurement\"] == \"dept_performance\") |> filter(fn: (r) => r[\"_field\"] == \"marks\") |> group(columns: [\"department\"]) |> mean()",
      "refId": "A"
    }
  ],
  "title": "Department Performance (Avg Marks)",
  "transformations": [
    {
      "id": "merge",
      "options": {}
    },
    {
      "id": "organize",
      "options": {
        "excludeByName": {
          "Time": True,
          "_field": True,
          "_measurement": True,
          "_start": True,
          "_stop": True,
          "_time": True
        },
        "renameByName": {
          "_value": "Avg Total Marks",
          "department": "Department"
        }
      }
    }
  ],
  "type": "barchart"
}

with open(file_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# Insert the panel back
panels = data.get("panels", [])
# Ensure we don't duplicate if it somehow exists
panels = [p for p in panels if p.get("id") != 2]
panels.insert(0, new_panel) # Put it at the beginning
data["panels"] = panels

# Restore positions of other panels
for panel in data.get("panels", []):
    if panel.get("id") == 1: # Grade Distribution
        panel["gridPos"]["w"] = 12
        panel["gridPos"]["x"] = 12
    elif panel.get("id") == 3: # Attendance per Department
        panel["gridPos"]["y"] = 10
        panel["gridPos"]["x"] = 0
        panel["gridPos"]["w"] = 12
    elif panel.get("id") == 4: # Backlog Distribution
        panel["gridPos"]["y"] = 10
        panel["gridPos"]["x"] = 12
        panel["gridPos"]["w"] = 12

with open(file_path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=4)

print("Panel restored successfully!")
