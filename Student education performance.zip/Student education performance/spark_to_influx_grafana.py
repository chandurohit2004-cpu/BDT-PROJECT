import os
import pandas as pd
import time
from datetime import datetime
try:
    from influxdb_client import InfluxDBClient, Point, WritePrecision
    from influxdb_client.client.write_api import SYNCHRONOUS
except ImportError:
    print("[!] influxdb-client not installed.")

TOKEN = "super-secret-spark-token"
ORG = "edu-analytics"
BUCKET = "academic_metrics"
URL = "http://localhost:8086"
PARQUET_PATH = "student_analytics_gold.parquet"

def stream_full_analytics():
    if not os.path.exists(PARQUET_PATH): return
    try:
        client = InfluxDBClient(url=URL, token=TOKEN, org=ORG)
        write_api = client.write_api(write_options=SYNCHRONOUS)
        df = pd.read_parquet(PARQUET_PATH)
        now = datetime.utcnow()

        # Overall Stats
        write_api.write(BUCKET, ORG, Point("academic_stats")
            .field("avg_attendance", float(df['Attendance (%)'].mean()))
            .field("at_risk_count", int(len(df[df['Attendance (%)'] < 75])))
            .time(now, WritePrecision.NS))
        print("--- Synced Overall Stats", flush=True)

        # Department Performance (Marks & Attendance)
        for dept, group in df.groupby('Department'):
            # Using tags for grouping results in clean legends in Grafana
            write_api.write(BUCKET, ORG, Point("dept_performance")
                .tag("department", str(dept))
                .field("marks", float(group['Total_Marks'].mean()))
                .field("attendance", float(group['Attendance (%)'].mean()))
                .time(now, WritePrecision.NS))
        print("--- Synced Department Performance", flush=True)

        # Grade Distribution
        for grade, count in df['Grade'].value_counts().items():
            write_api.write(BUCKET, ORG, Point("grade_stats")
                .tag("grade", str(grade))
                .field("count", int(count))
                .time(now, WritePrecision.NS))
        print("--- Synced Grade Distribution", flush=True)

        # Backlog Distribution
        # Specifically labeling them for a clean Pie chart legend
        for bl, count in df['Backlogs'].value_counts().items():
            label = f"{bl} Backlogs" if bl > 0 else "0 Backlogs"
            write_api.write(BUCKET, ORG, Point("backlog_stats")
                .tag("backlog_label", label)
                .field("count", int(count))
                .time(now, WritePrecision.NS))
        print("--- Synced Backlog Distribution", flush=True)

        print(f"[ACCURACY CHECK] Syncing {len(df)} records at {now}", flush=True)
        client.close()
    except Exception as e:
        print(f"[!] Error: {e}", flush=True)

if __name__ == "__main__":
    import sys
    if "--once" in sys.argv:
        stream_full_analytics()
    else:
        while True:
            stream_full_analytics()
            time.sleep(15)
