import sqlite3

try:
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT count(*) FROM students;")
    students_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT count(*) FROM users;")
    users_count = cursor.fetchone()[0]
    
    print(f"Students found: {students_count}")
    print(f"Users found: {users_count}")
    
    conn.close()
except Exception as e:
    print(f"Error: {e}")
