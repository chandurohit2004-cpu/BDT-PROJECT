import requests
from requests.auth import HTTPBasicAuth

URL = "http://localhost:3000/api/search"
USER = "admin"
PASS = "admin"

try:
    response = requests.get(URL, auth=HTTPBasicAuth(USER, PASS))
    if response.status_code == 200:
        dashboards = response.json()
        print("--- Dashboards found in Grafana ---")
        for d in dashboards:
            print(f"Title: {d['title']}, UID: {d['uid']}, URL: {d['url']}")
        
        found = any(d['uid'] == 'campus_analytics_v3' for d in dashboards)
        if found:
            print("\nSUCCESS: 'campus_analytics_v3' is available!")
        else:
            print("\nFAILURE: 'campus_analytics_v3' NOT FOUND in the list.")
    else:
        print(f"Error accessing API: {response.status_code} - {response.text}")
except Exception as e:
    print(f"Exception: {e}")
