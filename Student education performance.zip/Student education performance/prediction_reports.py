import pandas as pd
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

def generate_insights(model_file, transformed_data, metadata_file):
    # Load model and data
    with open(model_file, 'rb') as f:
        clf = pickle.load(f)
    
    with open(metadata_file, 'rb') as f:
        metadata = pickle.load(f)
        
    df = pd.read_csv(transformed_data)
    X = df.drop(columns=['Target_Grade'])
    
    # 1. Feature Importance Visualization
    importances = clf.feature_importances_
    feature_importance_df = pd.DataFrame({
        'Feature': X.columns,
        'Importance': importances
    }).sort_values(by='Importance', ascending=False)
    
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=feature_importance_df)
    plt.title('Key Factors Predicting College Student Success')
    plt.tight_layout()
    plt.savefig('feature_importance.png')
    print("Feature importance chart saved as 'feature_importance.png'")
    
    # 2. Identify "At-Risk" Students
    # Let's assume the LabelEncoder mapped the grades such that 'D' and 'F' are at-risk.
    # We need to map back using the encoder.
    le = metadata['label_encoder']
    target_classes = metadata['target_classes']
    
    # Predict grades for all students in the dataset
    df['Predicted_Grade_Value'] = clf.predict(X)
    df['Predicted_Grade'] = le.inverse_transform(df['Predicted_Grade_Value'])
    
    at_risk_grades = ['D', 'F']
    at_risk_students = df[df['Predicted_Grade'].isin(at_risk_grades)]
    
    print(f"\nTotal Students Analyzed: {len(df)}")
    print(f"Students Identified as 'At-Risk': {len(at_risk_students)}")
    
    # Save At-Risk Report
    at_risk_students.to_csv('at_risk_students_report.csv', index=False)
    print("Detailed report of at-risk students saved to 'at_risk_students_report.csv'")
    
    # 3. Summary for Educators
    top_factor = feature_importance_df.iloc[0]['Feature']
    print("\n--- EDUCATOR SUMMARY ---")
    print(f"Primary factor affecting student performance: {top_factor}")
    print(f"Intervention recommended for {len(at_risk_students)} students.")
    print("Check 'feature_importance.png' and 'at_risk_students_report.csv' for details.")

if __name__ == "__main__":
    generate_insights('student_performance_model.pkl', 'transformed_student_data.csv', 'transformation_metadata.pkl')
