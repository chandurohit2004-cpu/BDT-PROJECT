import sqlite3
import random

def rename_students():
    db_path = 'students.db'
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Common Indian names to make it more realistic for the context
    first_names = ["Aarav", "Vihaan", "Vivaan", "Ananya", "Diya", "Advait", "Ishani", "Kabir", "Myra", "Saanvi", 
                   "Arjun", "Aditya", "Sai", "Aaryan", "Krishna", "Ishaan", "Shaurya", "Atharv", "Aryan", "Rohan",
                   "Rahul", "Priya", "Sneha", "Aditi", "Riya", "Kavya", "Deepika", "Shreya", "Akash", "Karan"]
    
    last_names = ["Sharma", "Verma", "Gupta", "Malhotra", "Kapoor", "Singh", "Reddy", "Patel", "Iyer", "Nair",
                  "Choudhury", "Joshi", "Das", "Mehta", "Aggarwal", "Bhat", "Tiwari", "Yadav", "Patil", "Deshmukh"]

    # Get all student IDs
    cursor.execute("SELECT Student_ID FROM students")
    ids = cursor.fetchall()
    
    used_names = set()

    for student_id_row in ids:
        student_id = student_id_row[0]
        
        while True:
            new_name = f"{random.choice(first_names)} {random.choice(last_names)}"
            if new_name not in used_names:
                used_names.add(new_name)
                break
        
        cursor.execute("UPDATE students SET Student_Name = ? WHERE Student_ID = ?", (new_name, student_id))

    conn.commit()
    conn.close()
    print(f"Successfully renamed {len(ids)} students in students.db")

if __name__ == "__main__":
    rename_students()
